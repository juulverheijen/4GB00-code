% Pre-processing script for the EST Simulink model. This script is invoked
% before the Simulink model starts running (initFcn callback function).

%% Load the supply and demand data

timeUnit   = 's';

supplyFile = "Team10_supply.csv";
supplyUnit = "MW";

% load the supply data
Supply = loadSupplyData(supplyFile, timeUnit, supplyUnit);

demandFile = "Team10_demand.csv";
demandUnit = "MW";

% load the demand data
Demand = loadDemandData(demandFile, timeUnit, demandUnit);

%% Simulation settings

deltat = 5*unit("min");
stopt  = min([Supply.Timeinfo.End, Demand.Timeinfo.End]);

%% System parameters

% transport from supply
aSupplyTransport = 0.01; % Dissipation coefficient

% injection system
aInjection = 0.1; % Dissipation coefficient

% storage system
EStorageMax     = 600.*unit("MWh"); % Maximum energy
EStorageMin     = 0.0*unit("MWh"); % Minimum energy
EStorageInitial = 1.0*unit("MWh"); % Initial energy
bStorage        = 1e-6/unit("s");  % Storage dissipation coefficient
WInitial        = 0;               % Initial water level in the tank
V_tank = 2.8*10^5;                 % Total volume of the tank
P_initial = 65*10^5;               % Initial pressure

% extraction system
aExtraction = 0.175; % Dissipation coefficient

% transport to demand
aDemandTransport = 0.01; % Dissipation coefficient
